# Procédures & Fonctions

Procédure: __initialisation_grille__  
Création du support du jeu: on créer la grille vide

Paramètres:  
*grille* (Entrée/Sortie, tableau[1..LIGNE, 1..COLONNE] de caractère)

Résultat:  
Tableau vide à 2 dimensions

---------------------------------------------------------------------------------------------------------------
Procédure: __insertion_coup_grille__  
Les caractères ('O' ou 'X') sont implémentés dans la grille à chaque coup

Paramètres:  
*grille* (Entrée/Sortie, tableau[1..LIGNE, 1..COLONNE] de caractère)

Résultat:  
Les coups remplissent le tableau

---------------------------------------------------------------------------------------------------------------
Procédure: __affichage_grille__  
Affiche la grille (vide au 1er tour, et se remplie peu à peu au fil de la partie)

Paramètres:  
*Pas de paramètres*  

Résultat:  
La grille est affichée  

---------------------------------------------------------------------------------------------------------------
Fonction: __demande_coup__  
Demande au programme à quel joueur ira le prochain coup

Paramètres:  
*n* (Entrée): entier

Résultat:  
entier  

---------------------------------------------------------------------------------------------------------------
Fonction: __validation_coup__
Valide si le coup est autorisé ou non (un chiffre compris entre 1 et 7 inclus est autorisé)  
Maisu un nombre qui n'est pas compris dans cet intervalle ou alors un autre caractère comme une lettre n'est pas autorisé  

Paramètres:  
*n* (Entrée): entier  

Résultat:  
entier

---------------------------------------------------------------------------------------------------------------
Procédure: __position_coup__  
Calcule la position du coup qui a été joué  

Paramètres:
*n* (Entrée): entier
*pos_ligne* (Sortie): entier
*pos_colonne* (Sortie): entier  

Résultat:  
Position du coup joué  

---------------------------------------------------------------------------------------------------------------  
Fonction: __grille_complete__  
Vérifie si la grille est totalement complète et qu'il n'est plus possible de jouer  
Elle n'est pas utilisée dans le programme principal, mais est utilisée dans la fonction "statut_du_jeu"

Paramètres:  
*Pas de paramètres*  

---------------------------------------------------------------------------------------------------------------
Fonction __statut_du_jeu__  
Donne la victoire si 4 jetons sont alignés, de façon verticale, horizontale ou en diagonale  
Si lorsque la grille est totalement remplie, aucun joueur n'a gagné, alors renvoie une égalité  
Cette fonction fait appel à la fonction "grille_complete"  

Paramètres:  
*chaîne* (Entrée): caractère  
*pos_ligne* (Sortie): entier  
*pos_colonne* (Sortie): entier  

Résultat:  
Renvoie une victoire ou une égalité  

---------------------------------------------------------------------------------------------------------------  
Procédure: __tour_du_joueur__  
Indique quel joueur doit jouer  
  
Paramètres:  
*Pas de paramètres*  

Résultat:  
Renvoie un écrireEcran("Joueur "" à votre tour de jouer") (1 ou 2)  

---------------------------------------------------------------------------------------------------------------
Procédure: __jeton_a_jouer__  
Définis si c'est le jeton prend la valeur de 'O' ou de 'X'

Paramètres:
*char* (Entrée): caractère  

Résultat:  
Le jeton prend la valeur 'O' ou 'X'  

---------------------------------------------------------------------------------------------------------------
Procédure: __winner_ou_draw__  
Décide qui a gagné la partie, s'il y a un gagnant  
S'il n'y a pas de gagnant alors il y a une égalité  
S'il n'y a rien, alors le jeu se poursuit  

Paramètres:  
*Pas de paramètres*  

Résultat:  
S'il y a un gagnant: renvoie un écrireEcran("Le joueur "" à remporté la partie.") (1 ou 2)  
S'il n'y a pas de gagnant: renvoie un écrireEcran("Egalité, aucun joueur n'a remporté la partie.")  
Si la partie n'est pas encore terminée et qu'il n'y a ni gagnant si égalité alors le jeu continue  