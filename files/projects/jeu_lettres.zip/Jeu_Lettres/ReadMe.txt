Projet realisé en classe de Première NSI, sur EduPython.
Ce programme est inspiré du jeu "Des Chiffres Et Des Lettres".

Il permet de jouer à la partie "Lettres".
Tour à tour, 2 joueurs vont avoir le choix entre "consonne" et "voyelle", pour un total de 9 lettres.
Lorsque "consonne" sera choisie, une consonne au hasard sera donnée comme lettre. Lorsque "voyelle" sera choisie, une voyelle au hasard sera donnée comme lettre. Il doit y avoir aux minimums 2 voyelles.

Une fois le tirage effectué, les joueurs inscriront l'un après l'autre un mot comportant les lettres affichées 
(attention, une lettre ne peut être utilisée qu'une seule fois).
Lorsque les 2 joueurs ont inscrit leur mot, c'est le joueur qui a le plus long mot qui remporte la partie.
Si les joueurs ont des mots de même longueur, alors il y a égalité.

