Ce projet a été réalisé en 1ère Année de BUT Informatique.
Ce programme permet de jouer une partie de 'Puissance 4'.

2 joueurs s'affrontent chacun leur tour dans une grille de jeu, comptant 6 rangées et 7 colonnes.
Le but du jeu est d'aligner une 4 jetons de même couleur dans la grille de jeu. Chaque joueur place tour à tour un pion de sa couleur dans la colonne de leur choix.

Le vainqueur est le joueur qui réalise en premier un alignement horizontal, vertical ou diagonal, consécutif, de 4 jetons de sa couleur.
Si la grille est remplie et qu'il n'y a pas d'alignement, alors y a match nul.

